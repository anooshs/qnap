import { transformAll } from '@angular/compiler/src/render3/r3_ast';
import { Component, OnInit, Pipe } from '@angular/core';
import  MOCK_DATA  from '../assets/MOCK_DATA.json';

interface Details {  
  id: Number;  
  first_name: String;  
  last_name: String;
  email: String;  
  gender: String;  
  timestamp: string;
  ip_address: string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Table with Filter and Sorting';
  
  arrData: Details[] = MOCK_DATA;
  searchIDValue: any;
  searchFirstNameValue: any;
  searchLastNameValue: any;
  searchEmailValue: any;
  searchGenderValue: any;
  searchDateValue: any;
  booleanValue: any = false;
  page: any = 1; 
  
  ngOnInit(){
    /* this.arrData = MOCK_DATA.map(temp => {
      temp.timestamp = new Date(temp.timestamp);
      return temp;
    }); */
  }

  searchID(){
    if(this.searchIDValue !== "") {
      this.arrData = MOCK_DATA.filter(item => {
          return item.id.toString().toLowerCase().includes(this.searchIDValue.toLowerCase());
      });
    } else
      this.arrData = MOCK_DATA;
  }

  searchFirstName(){
    if(this.searchFirstNameValue !== "") {
      this.arrData = this.arrData.filter(item => {
          return item.first_name.toLowerCase().includes(this.searchFirstNameValue.toLowerCase());
      });
    } else
      this.arrData = MOCK_DATA;
  }

  searchLastName(){
    if(this.searchLastNameValue !== "") {
      this.arrData = this.arrData.filter(item => {
          return item.last_name.toLowerCase().includes(this.searchLastNameValue.toLowerCase());
      });
    } else
      this.arrData = MOCK_DATA;
  }

  searchEmail(){
    if(this.searchEmailValue !== "") {
      this.arrData = this.arrData.filter(item => {
          return item.email.toLowerCase().includes(this.searchEmailValue.toLowerCase());
      });
    } else
      this.arrData = MOCK_DATA;
  }

  searchGender(){
    if(this.searchGenderValue !== "") {
      this.arrData = this.arrData.filter(item => {
          return item.gender.toLowerCase().includes(this.searchGenderValue.toLowerCase());
      });
    } else
      this.arrData = MOCK_DATA;
  }

  searchDate(){
    if(this.searchDateValue !== "") {
      this.arrData = this.arrData.filter(item => {
          return item.timestamp.includes(Date.parse(this.searchDateValue).toString());
      });
    } else
      this.arrData = MOCK_DATA;
  }

  sortIDFunction(boolean: any) {
    if (boolean == true){
        this.arrData.sort((a, b) => a.id < b.id ? 1 : a.id > b.id ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
    else{
        this.arrData.sort((a, b) => a.id > b.id ? 1 : a.id < b.id ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
  }

  sortFNameFunction(boolean: any) {
    if (boolean == true){
        this.arrData.sort((a, b) => a.first_name < b.first_name ? 1 : a.first_name > b.first_name ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
    else{
        this.arrData.sort((a, b) => a.first_name > b.first_name ? 1 : a.first_name < b.first_name ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
  }

  sortLNameFunction(boolean: any) {
    if (boolean == true){
        this.arrData.sort((a, b) => a.last_name < b.last_name ? 1 : a.last_name > b.last_name ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
    else{
        this.arrData.sort((a, b) => a.last_name > b.last_name ? 1 : a.last_name < b.last_name ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
  }

  sortEmailFunction(boolean: any) {
    if (boolean == true){
        this.arrData.sort((a, b) => a.email < b.email ? 1 : a.email > b.email ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
    else{
        this.arrData.sort((a, b) => a.email > b.email ? 1 : a.email < b.email ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
  }

  sortGenderFunction(boolean: any) {
    if (boolean == true){
        this.arrData.sort((a, b) => a.gender < b.gender ? 1 : a.gender > b.gender ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
    else{
        this.arrData.sort((a, b) => a.gender > b.gender ? 1 : a.gender < b.gender ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
  }

  sortDateFunction(boolean: any) {
    if (boolean == true){
        this.arrData.sort((a, b) => a.timestamp < b.timestamp ? 1 : a.timestamp > b.timestamp ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
    else{
        this.arrData.sort((a, b) => a.timestamp > b.timestamp ? 1 : a.timestamp < b.timestamp ? -1 : 0)
        this.booleanValue = !this.booleanValue
    }
  }
}
